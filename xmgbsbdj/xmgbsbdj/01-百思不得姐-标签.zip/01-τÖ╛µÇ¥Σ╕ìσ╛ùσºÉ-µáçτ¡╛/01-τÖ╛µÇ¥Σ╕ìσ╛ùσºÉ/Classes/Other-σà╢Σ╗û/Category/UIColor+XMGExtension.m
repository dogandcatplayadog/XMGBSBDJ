//
//  UIColor+XMGExtension.m
//  01-百思不得姐
//
//  Created by xiaomage on 15/8/6.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "UIColor+XMGExtension.h"

@implementation UIColor (XMGExtension)
+ (UIColor *)colorWithKey:(NSString *)key
{
//    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"colors" ofType:@"plist"]];
//    
//    NSString *colorString = dict[@"normal"][key];
//    
//    return XMGRGBColor(<#r#>, <#g#>, <#b#>)
    return nil;
}
@end
